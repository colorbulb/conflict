// Firestore Timestamp export helper
import { Timestamp } from 'firebase/firestore';
export { Timestamp };