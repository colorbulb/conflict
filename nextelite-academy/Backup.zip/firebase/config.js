// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyANDwix9QLvTBxmgksPumap7oEihe2UdYE",
  authDomain: "nextelitefnweb.firebaseapp.com",
  projectId: "nextelitefnweb",
  storageBucket: "nextelitefnweb.firebasestorage.app",
  messagingSenderId: "496900220544",
  appId: "1:496900220544:web:5d627b87ee1ec0e2e76865"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);