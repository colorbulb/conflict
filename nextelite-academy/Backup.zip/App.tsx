import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Section, Course, AppData, ThemeColors, TrialSettings, Submission, BlogPost, Instructor } from './types';
import { INITIAL_DATA, ICONS } from './constants';
import { LanguageProvider, useLanguage } from './components/LanguageContext';
import FloatingShape from './components/FloatingShape';
import CourseCard from './components/CourseCard';
import CourseDetail from './components/CourseDetail';
import ChatWidget from './components/ChatWidget';
import ContactForm from './components/ContactForm';
import AdminLogin from './components/AdminLogin';
import CMSDashboard from './components/CMSDashboard';
import BookingModal from './components/BookingModal';
import BlogList from './components/BlogList';
import BlogPostDetail from './components/BlogPostDetail';
import { Menu, X, Globe, UserCog } from 'lucide-react';

const AppContent: React.FC = () => {
  const { language, setLanguage, t } = useLanguage();
  
  // State for the application data (Mock Database)
  const [db, setDb] = useState<{ en: AppData; zh: AppData }>(INITIAL_DATA);
  
  // Admin State
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Navigation State
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeCourseId, setActiveCourseId] = useState<string | null>(null);
  const [activePostId, setActivePostId] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<Section>(Section.HOME);

  // Modal State
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  // Helper to get current data based on language
  const currentData = db[language];

  // Helper to map icon string to ReactNode
  const getCourseWithIcon = (course: Course) => ({
    ...course,
    icon: typeof course.icon === 'string' ? ICONS[course.icon as keyof typeof ICONS] : course.icon
  });

  // Apply Theme Colors to CSS Variables
  useEffect(() => {
    const root = document.documentElement;
    const colors = currentData.themeColors;
    root.style.setProperty('--color-brand-yellow', colors.yellow);
    root.style.setProperty('--color-brand-orange', colors.orange);
    root.style.setProperty('--color-brand-blue', colors.blue);
    root.style.setProperty('--color-brand-green', colors.green);
    root.style.setProperty('--color-brand-purple', colors.purple);
  }, [currentData.themeColors]);

  const handleUpdateCourse = (course: Course) => {
    setDb(prev => {
        const langData = prev[language];
        const exists = langData.courses.find(c => c.id === course.id);
        const newCourses = exists 
            ? langData.courses.map(c => c.id === course.id ? course : c)
            : [...langData.courses, course];
        
        return {
            ...prev,
            [language]: {
                ...langData,
                courses: newCourses
            }
        };
    });
  };

  const handleUpdateInstructor = (instructor: Instructor) => {
      setDb(prev => {
        const langData = prev[language];
        const exists = langData.instructors.find(i => i.id === instructor.id);
        const newInstructors = exists 
            ? langData.instructors.map(i => i.id === instructor.id ? instructor : i)
            : [...langData.instructors, instructor];
        
        return {
            ...prev,
            [language]: {
                ...langData,
                instructors: newInstructors
            }
        };
    });
  };

  const handleUpdateBlog = (updatedPosts: BlogPost[]) => {
      setDb(prev => ({
          ...prev,
          [language]: {
              ...prev[language],
              blogPosts: updatedPosts
          }
      }));
  };

  const handleUpdateTheme = (colors: ThemeColors) => {
      // Update theme for both languages for consistency in this demo
      setDb(prev => ({
          en: { ...prev.en, themeColors: colors },
          zh: { ...prev.zh, themeColors: colors }
      }));
  };

  const handleUpdateTrial = (settings: TrialSettings) => {
      // Update trial settings for both languages
      setDb(prev => ({
          en: { ...prev.en, trialSettings: settings },
          zh: { ...prev.zh, trialSettings: settings }
      }));
  };

  const handleSubmission = (data: Omit<Submission, 'id' | 'status'>) => {
    const newSubmission: Submission = {
      ...data,
      id: Math.random().toString(36).substr(2, 9),
      status: 'new'
    };

    setDb(prev => ({
      en: { ...prev.en, submissions: [newSubmission, ...prev.en.submissions] },
      zh: { ...prev.zh, submissions: [newSubmission, ...prev.zh.submissions] }
    }));
  };

  const scrollToSection = (id: string) => {
    setActiveCourseId(null);
    setActivePostId(null);
    setIsAdminMode(false);
    
    // If it's the blog section, we want to render the Blog View, not scroll to an ID on the home page (unless blog is on home page, but we made it a separate view conceptually here)
    if (id === Section.BLOG) {
        setActiveSection(Section.BLOG);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
        setActiveSection(Section.HOME);
        // Delay scroll to allow Home component to mount if we were elsewhere
        setTimeout(() => {
            const element = document.getElementById(id);
            if (element) {
                element.scrollIntoView({ behavior: 'smooth' });
            } else if (id === Section.HOME) {
                 window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }, 100);
    }
    setMobileMenuOpen(false);
  };

  const handleViewCourse = (id: string) => {
    setActiveCourseId(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewPost = (id: string) => {
      setActivePostId(id);
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeCourse = activeCourseId ? currentData.courses.find(c => c.id === activeCourseId) : null;
  const activePost = activePostId ? currentData.blogPosts.find(p => p.id === activePostId) : null;

  const navLinks = [
    { label: t.nav[Section.COURSES], id: Section.COURSES },
    { label: t.nav[Section.BLOG], id: Section.BLOG },
    { label: t.nav[Section.INSTRUCTORS], id: Section.INSTRUCTORS },
    { label: t.nav[Section.GALLERY], id: Section.GALLERY },
    { label: t.nav[Section.CONTACT], id: Section.CONTACT },
  ];

  // If Admin Mode is active
  if (isAdminMode) {
      if (!isLoggedIn) {
          return <AdminLogin onLogin={() => setIsLoggedIn(true)} />;
      }
      return (
          <CMSDashboard 
            courses={currentData.courses} 
            instructors={currentData.instructors}
            blogPosts={currentData.blogPosts}
            themeColors={currentData.themeColors}
            trialSettings={currentData.trialSettings}
            submissions={currentData.submissions}
            onUpdateCourse={handleUpdateCourse}
            onUpdateInstructor={handleUpdateInstructor}
            onUpdateTheme={handleUpdateTheme}
            onUpdateTrial={handleUpdateTrial}
            onUpdateBlog={handleUpdateBlog}
            onLogout={() => { setIsLoggedIn(false); setIsAdminMode(false); }}
          />
      );
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-white text-slate-800 font-sans bg-gradient-to-br from-gray-50 via-white to-gray-50">
      
      {/* Booking Modal */}
      <BookingModal 
        isOpen={isBookingModalOpen} 
        onClose={() => setIsBookingModalOpen(false)}
        courses={currentData.courses}
        onSubmit={handleSubmission}
        blockedDates={currentData.trialSettings.blockedDates}
        customAvailability={currentData.trialSettings.customAvailability}
      />

      {/* Background Shapes */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <FloatingShape color="bg-brand-yellow" size="400px" top="-100px" left="-100px" delay={0} />
        <FloatingShape color="bg-brand-blue" size="300px" top="40%" left="80%" delay={2} />
        <FloatingShape color="bg-brand-green" size="250px" top="80%" left="10%" delay={4} />
      </div>

      {/* Navigation */}
      <nav className="fixed w-full z-40 bg-white/80 backdrop-blur-md border-b border-gray-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div 
                className="flex-shrink-0 flex items-center cursor-pointer group" 
                onClick={() => scrollToSection(Section.HOME)}
            >
               <span className="text-3xl font-display font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-orange to-brand-blue group-hover:scale-105 transition-transform duration-300 inline-block">
                 NextElite Academy
               </span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex space-x-6 items-center">
              {navLinks.map((link) => (
                <button 
                  key={link.id} 
                  onClick={() => scrollToSection(link.id)}
                  className="text-gray-600 hover:text-brand-blue font-semibold transition-colors"
                >
                  {link.label}
                </button>
              ))}
              
              {/* Language Switcher */}
              <button 
                onClick={() => setLanguage(language === 'en' ? 'zh' : 'en')}
                className="flex items-center space-x-1 text-gray-500 hover:text-brand-blue border border-gray-200 rounded-full px-3 py-1 transition-all"
              >
                <Globe className="w-4 h-4" />
                <span className="text-sm font-bold uppercase">{language}</span>
              </button>

              {currentData.trialSettings.enabled ? (
                <button 
                  onClick={() => setIsBookingModalOpen(true)}
                  className="bg-brand-blue text-white px-6 py-2 rounded-full font-bold hover:bg-brand-purple transition-all hover:scale-105 shadow-md hover:shadow-lg"
                >
                  {t.nav.enroll}
                </button>
              ) : (
                <button disabled className="bg-gray-300 text-white px-6 py-2 rounded-full font-bold cursor-not-allowed">
                   Full
                </button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center space-x-4">
               <button 
                onClick={() => setLanguage(language === 'en' ? 'zh' : 'en')}
                className="flex items-center space-x-1 text-gray-600 border border-gray-200 rounded-full px-3 py-1"
              >
                <Globe className="w-4 h-4" />
                <span className="text-sm font-bold uppercase">{language}</span>
              </button>
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="text-gray-600">
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden bg-white border-b border-gray-100 shadow-xl overflow-hidden"
            >
              <div className="px-4 pt-2 pb-6 space-y-1 sm:px-3 flex flex-col items-center">
                {navLinks.map((link) => (
                  <button
                    key={link.id}
                    onClick={() => scrollToSection(link.id)}
                    className="block px-3 py-3 rounded-md text-base font-medium text-gray-700 hover:text-brand-blue hover:bg-gray-50 w-full text-center active:bg-gray-100"
                  >
                    {link.label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Main Content View Switch */}
      <AnimatePresence mode="wait">
        {activeCourse ? (
            <CourseDetail 
                key="detail"
                course={getCourseWithIcon(activeCourse)} 
                onBack={() => setActiveCourseId(null)} 
                onEnroll={() => {
                   setIsBookingModalOpen(true);
                   setActiveCourseId(null);
                }}
            />
        ) : activePost ? (
            <BlogPostDetail 
                key="post-detail"
                post={activePost}
                onBack={() => setActivePostId(null)}
            />
        ) : activeSection === Section.BLOG ? (
            <BlogList 
                key="blog-list"
                posts={currentData.blogPosts}
                onReadMore={handleViewPost}
            />
        ) : (
            <motion.div 
                key="home"
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }}
            >
                {/* Hero Section */}
                <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 px-4 text-center">
                    <div className="max-w-5xl mx-auto">
                    <motion.h1 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-5xl md:text-7xl font-display font-bold text-gray-900 mb-6 leading-tight"
                    >
                        {t.hero.titleLine1} <br/>
                        <span className="text-brand-orange">{t.hero.titleLine2}</span>
                    </motion.h1>
                    <motion.p 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto leading-relaxed"
                    >
                        {t.hero.subtitle}
                    </motion.p>
                    <motion.div 
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.4 }}
                        className="flex flex-col sm:flex-row justify-center gap-4"
                    >
                        <button 
                        onClick={() => scrollToSection(Section.COURSES)}
                        className="bg-brand-blue text-white px-8 py-4 rounded-full font-bold text-lg shadow-lg hover:shadow-xl hover:bg-brand-purple transition-all transform hover:-translate-y-1"
                        >
                        {t.hero.explore}
                        </button>
                        
                        {currentData.trialSettings.enabled ? (
                            <button 
                            onClick={() => setIsBookingModalOpen(true)}
                            className="bg-white text-brand-orange border-2 border-brand-orange px-8 py-4 rounded-full font-bold text-lg shadow-sm hover:bg-orange-50 transition-all transform hover:-translate-y-1"
                            >
                            {t.hero.trial}
                            </button>
                        ) : (
                             <button 
                             disabled
                            className="bg-gray-100 text-gray-400 border-2 border-gray-200 px-8 py-4 rounded-full font-bold text-lg cursor-not-allowed"
                            >
                             Class Full
                            </button>
                        )}
                    </motion.div>
                    
                    {currentData.trialSettings.enabled && (
                        <motion.div
                           initial={{ opacity: 0 }}
                           animate={{ opacity: 1 }}
                           transition={{ delay: 1 }}
                           className="mt-6 text-sm font-semibold text-brand-green bg-green-50 inline-block px-4 py-1 rounded-full border border-brand-green/20"
                        >
                            {currentData.trialSettings.message} ({currentData.trialSettings.slotsAvailable} slots left)
                        </motion.div>
                    )}

                    </div>
                </section>

                {/* Courses Section */}
                <section id={Section.COURSES} className="py-20 relative bg-white/40 backdrop-blur-sm">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-display font-bold text-gray-900 mb-4">{t.headings.programs}</h2>
                        <p className="text-gray-600 max-w-2xl mx-auto text-lg">{t.headings.programsSub}</p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {currentData.courses.map((course) => (
                        <CourseCard 
                            key={course.id} 
                            course={getCourseWithIcon(course)} 
                            onViewDetails={handleViewCourse}
                        />
                        ))}
                    </div>
                    </div>
                </section>

                {/* Instructors Section */}
                <section id={Section.INSTRUCTORS} className="py-20 bg-brand-yellow/10">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-display font-bold text-gray-900 mb-4">{t.headings.mentors}</h2>
                        <p className="text-gray-600 text-lg">{t.headings.mentorsSub}</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {currentData.instructors.map((instructor, idx) => (
                        <motion.div 
                            key={instructor.id}
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: idx * 0.1 }}
                            className="bg-white p-8 rounded-3xl shadow-md text-center group hover:shadow-2xl transition-all duration-300 border border-gray-100"
                        >
                            <div className="w-32 h-32 mx-auto mb-6 rounded-full overflow-hidden border-4 border-brand-yellow group-hover:scale-110 transition-transform duration-300 shadow-lg">
                            <img src={instructor.imageUrl} alt={instructor.name} className="w-full h-full object-cover" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mb-1">{instructor.name}</h3>
                            <p className="text-brand-blue font-bold text-sm mb-4 uppercase tracking-wide">{instructor.role}</p>
                            <p className="text-gray-500 leading-relaxed">{instructor.bio}</p>
                        </motion.div>
                        ))}
                    </div>
                    </div>
                </section>

                {/* Gallery Section */}
                <section id={Section.GALLERY} className="py-20">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-display font-bold text-gray-900 mb-4">{t.headings.gallery}</h2>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {/* Gallery images are shared across languages for now */}
                        {['https://picsum.photos/id/20/800/600',
                          'https://picsum.photos/id/119/800/600',
                          'https://picsum.photos/id/180/800/600',
                          'https://picsum.photos/id/201/800/600',
                          'https://picsum.photos/id/250/800/600',
                          'https://picsum.photos/id/366/800/600'].map((src, idx) => (
                        <motion.div 
                            key={idx}
                            initial={{ opacity: 0, scale: 0.9 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            whileHover={{ scale: 1.05, zIndex: 10 }}
                            className="rounded-2xl overflow-hidden h-48 md:h-64 shadow-md cursor-pointer transition-transform duration-300"
                        >
                            <img src={src} alt={`Gallery ${idx}`} className="w-full h-full object-cover" />
                        </motion.div>
                        ))}
                    </div>
                    </div>
                </section>

                {/* Contact Section */}
                <section id={Section.CONTACT} className="py-20 bg-gradient-to-br from-brand-yellow/20 to-brand-orange/10">
                    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row">
                        
                        <div className="p-10 md:w-5/12 bg-brand-blue text-white flex flex-col justify-between relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                            <div className="relative z-10">
                                <h2 className="text-3xl font-display font-bold mb-6">{t.headings.contact}</h2>
                                <p className="mb-8 text-blue-100 leading-relaxed">{t.headings.contactSub}</p>
                                
                                <div className="space-y-6">
                                    <div className="flex items-start space-x-4">
                                        <div className="w-1 bg-brand-yellow h-12 rounded-full opacity-50"></div>
                                        <div>
                                            <p className="font-bold opacity-80 uppercase text-xs tracking-wider">Address</p>
                                            <p className="text-lg">123 Education Rd, Innovation District</p>
                                        </div>
                                    </div>
                                     <div className="flex items-start space-x-4">
                                        <div className="w-1 bg-brand-yellow h-12 rounded-full opacity-50"></div>
                                        <div>
                                            <p className="font-bold opacity-80 uppercase text-xs tracking-wider">Email</p>
                                            <p className="text-lg">hello@nextelite.edu</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="p-10 md:w-7/12 bg-white">
                            <ContactForm trialSettings={currentData.trialSettings} onSubmit={handleSubmission} />
                        </div>

                    </div>
                    </div>
                </section>
            </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="bg-brand-purple text-gray-300 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-3xl font-display font-bold text-white mb-4 block">NextElite Academy</span>
          <p className="mb-8 max-w-lg mx-auto text-gray-400">{t.footer.desc}</p>
          <div className="flex justify-center space-x-6 mb-8 text-sm font-semibold">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <button onClick={() => setIsAdminMode(true)} className="hover:text-white transition-colors flex items-center gap-1">
                 <UserCog className="w-3 h-3" /> {t.footer.admin}
              </button>
          </div>
          <p className="text-sm">{t.footer.rights}</p>
        </div>
      </footer>

      {/* AI Chatbot Widget */}
      <ChatWidget />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
};

export default App;